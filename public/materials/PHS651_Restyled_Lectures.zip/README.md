# PHS 651 lecture slides

Filename convention: `PHS651_Lecture_NN_Topic.pptx`.

Each deck retains its original slide order, equations, images, and notes. Minimal corrections to wording and time-unit labels are included. Title pages and slide headings share the same visual theme. The source files in Dropbox remain unchanged.

| Lecture | Topic | Slides | Original filename |
| --- | --- | ---: | --- |
| 01 | Introduction | 29 | slides.pptx |
| 02 | Linear Regression, Maximum Likelihood, and ANOVA | 35 | slides2.pptx |
| 03 | Descriptive and Graphical Analysis Using SAS | 25 | slides3.pptx |
| 04 | Single-Group Analysis and General Linear Models | 33 | slides4.pptx |
| 05 | Estimation and Inference in the General Linear Model | 31 | slides5.pptx |
| 06 | Analysis of Response Profiles | 24 | slides6.pptx |
| 07 | More on Analysis of Response Profiles | 24 | slides7.pptx |
| 08 | Modeling the Mean: Parametric Curves | 28 | slides8.pptx |
| 09 | Modeling the Covariance | 33 | slides9.pptx |
| 10 | Linear Mixed Effects Models | 32 | slides10.pptx |
| 11 | Prediction in Mixed Effects Models | 27 | slides11.pptx |
| 12 | Design of Longitudinal Studies | 27 | slides12.pptx |
| 13 | Residual Analysis and Diagnostics | 26 | slides13.pptx |
| 14 | Generalized Linear Models for Longitudinal Data | 13 | slides14.pptx |
| 15 | Marginal Models: Generalized Estimating Equations | 18 | slides15.pptx |
| 16 | Case Studies of Marginal Models | 23 | slides16.pptx |
| 17 | Generalized Linear Mixed Effects Models | 15 | slides17.pptx |
| 18 | Contrasting GLMM and GEE | 26 | slides18.pptx |
| 19 | Missing Data and Multiple Imputation | 33 | slides19.pptx |
| 20 | Inverse Probability Weighting for Missing Data | 24 | slides20.pptx |
| 21 | Smoothing Longitudinal Data: Semiparametric Regression Models | 23 | slides21.pptx |
| 22 | Multilevel Models | 23 | slides22.pptx |
| 23 | Special Topic: Repeated-Measures Designs | 20 | slides23.pptx |
| 24 | Review and Prospects | 15 | slides24.pptx |
